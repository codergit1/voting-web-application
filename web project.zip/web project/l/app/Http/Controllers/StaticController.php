<?php

namespace App\Http\Controllers;

use Illuminate\Routing\Controller as BaseController;
class StaticController extends BaseController{
     
    function index(){
        return view('index');
    }

    function about(){
        return view('about');
    }

    function campaign(){
        return view('campaign');
    }

    function vote(){
        return view('vote');
    }
}

?>