<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="about-style.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="http://code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css" />
</head>

<body>

    <nav class="navbar navbar-expand-lg navbar-ligth bg-light static-top">
        <div class="container">
            <a class="navbar-brand" href="{{url('index')}}">
                <img class="logo" src="logo.png" alt="GoElect!">
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive"
                aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="{{url('index')}}">Home

                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="{{url('campaign')}}">Campaign</a>
                        <span class="sr-only">(current)</span>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{url('vote')}}">Vote</a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="{{url('about')}}">About</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <section class="toper padding-lg">
        <div class="container">

            <ul class="row">
                <!--<li class="col-12 col-md-6 col-lg-3">-->
                <li class="col col-lg-3 ml-3 mr-5">
                    <div class="cnt-block equal-height" style="height: 349px;">
                        <figure><img src="Ulugbek.jpg" class="img-responsive" alt="Ulugbek">
                        </figure>
                        <h3>Ulugbek</h3>
                        <p>Sejong University</p>
                        <ul class="follow-us clearfix">
                            <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                            <li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                        </ul>
                    </div>
                </li>
                <li class="col col-lg-3 ml-5 mr-5">
                    <div class="cnt-block equal-height" style="height: 349px;">
                        <figure><img src="Yakhyo.jpg" class="img-responsive" alt="">
                        </figure>
                        <h3><a href="#">Yakhyo </a></h3>
                        <p>Sejong University</p>
                        <ul class="follow-us clearfix">
                            <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                            <li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                        </ul>
                    </div>
                </li>
                <li class="col col-lg-3 ml-5 mr-1">
                    <div class="cnt-block equal-height" style="height: 349px;">
                        <figure><img src="Soundarya.jpg" class="img-responsive" alt="">
                        </figure>
                        <h3><a href="">Soundarya</a></h3>
                        <p>Sejong University</p>
                        <ul class="follow-us clearfix">
                            <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                            <li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                        </ul>
                    </div>
                </li>
            </ul>
        </div>
    </section>

    <!-- Footer -->
    <footer class="page-footer h-5 w-100 font-small bg-secondary text-white">

        <!-- Copyright -->
        <div class="footer-copyright text-center py-3" id="colour">© 2019 [Spring Semester] Copyright Team 6 | Web
            Programming | Sejong University
        </div>
        <!-- Copyright -->

    </footer>
    <!-- Footer -->
    <script>
        window.onscroll = function () {
            myFunction()
        };

        function myFunction() {
            var winScroll = document.body.scrollTop || document.documentElement.scrollTop;
            var height = document.documentElement.scrollHeight - document.documentElement.clientHeight;
            var scrolled = (winScroll / height) * 100;
            document.getElementById("myBar").style.width = scrolled + "%";
        }
    </script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="http://code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css" />
</body>

</html>