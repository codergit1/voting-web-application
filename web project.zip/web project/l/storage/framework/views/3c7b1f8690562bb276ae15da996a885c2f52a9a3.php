<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <link rel="stylesheet" href="style.css">
    <title>GoElect!</title>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="http://code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css" />

    <!-- csrf token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">


<script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
</head>

<body>
    <header>
        <div class="overlay"></div>
        <video playsinline="playsinline" autoplay="autoplay" muted="muted" loop="loop">
            <source src="homepage.mp4" type="video/mp4">
        </video>

        <div class="container h-100 mr-3">

            <a href="<?php echo e(url('index')); ?>">

                <img src="logo.png" class="rounded float-left" alt="GoElect!"></a>
            <!--<div class="d-flex h-100 text-center align-items-center">-->

            <div class="d-flex float-right p-10" id="box">
              <?php if(auth()->guard()->guest()): ?>
               <div class="login"><a href="<?php echo e(url('/login')); ?>" class="btn btn-light w-2" role="button">Login</a>
                </div>
                <?php if(Route::has('register')): ?>
                <div class="re"><a href="<?php echo e(url('/register')); ?>" class="btn btn-dark w-2" role="button">Register</a>
                </div>
                <?php endif; ?>
            <?php else: ?>
            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                                </a>

                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                       
<?php endif; ?>
         

            </div>
            


            <div class="d-flex h-100 align-items-center">
                <div class="menu d-flex flex-row justify-content-center w-100 text-white text-100">
                    <!-- w-100-->
                    <!-- p-2 -->
                    <div class="pl-3 pr-5"><a href="<?php echo e(url('index')); ?>" class="text-white" alt="Home"> Home</a></div>
                    <div class="pl-3 pr-5"><a href="<?php echo e(url('campaign')); ?>" class="text-white" alt="Campaign">Campaign</a>
                    </div>
                    <div class="pl-3 pr-5"><a href="<?php echo e(url('about')); ?>" class="text-white" alt="About">About</a></div>

                    <div class="vote btn btn-info rounded" href="#" role="button">
                        <a href="<?php echo e(url('/vote')); ?>" class="btn text-white" href="#">
                            VOTE
                        </a>
                    </div>
                </div>
            </div>
    </header>

    <section class="my-5">
        <div class="container">
            <div class="row">
                <div class="col-md-7 mx-auto">
                    <blockquote class="blockquote">
                        <p class="mb-0">"The right of election is the very essence of the constitution."</p>
                        <footer class="blockquote-footer text-right"><cite title="Source Title">Junius</cite></footer>
                    </blockquote>
                </div>
            </div>
        </div>
    </section>


    <!-- Footer -->
    <footer class="page-footer h-5 w-100 font-small bg-secondary text-white">

        <!-- Copyright -->
        <div class="footer-copyright text-center py-3" id="colour">© 2019 [Spring Semester] Copyright Team 6 | Web
            Programming | Sejong University
        </div>
        <!-- Copyright -->

    </footer>
    <!-- Footer -->


    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
        integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
        integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous">
    </script>
</body>

</html><?php /**PATH C:\Users\Soundarya\Desktop\web project\l\resources\views/index.blade.php ENDPATH**/ ?>