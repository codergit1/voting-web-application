<!-- <!DOCTYPE html>
<html>

<head>

  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <style>
    body {
      font-family: Arial, Helvetica, sans-serif;
      background-color: black;
    }

    * {
      box-sizing: border-box;
    }

    /* Add padding to containers */
    .container {
      padding: 16px;
      background-color: white;
    }

    /* Full-width input fields */
    input[type="text"],
    input[type="password"] {
      width: 100%;
      padding: 15px;
      margin: 5px 0 22px 0;
      display: inline-block;
      border: none;
      background: #f1f1f1;
    }

    input[type="text"]:focus,
    input[type="password"]:focus {
      background-color: #ddd;
      outline: none;
    }

    /* Overwrite default styles of hr */
    hr {
      border: 1px solid #f1f1f1;
      margin-bottom: 25px;
    }

    /* Set a style for the submit button */
    .registerbtn {
      background-color: black;
      color: white;
      padding: 16px 20px;
      margin: 8px 0;
      border: none;
      cursor: pointer;
      width: 100%;
      opacity: 0.9;
    }

    .registerbtn:hover {
      opacity: 1;
    }

    /* Add a blue text color to links */
    a {
      color: dodgerblue;
    }

    /* Set a grey background color and center the text of the "sign in" section */
    .signin {
      background-color: #f1f1f1;
      text-align: center;
    }
  </style>
</head>

<body>
  <div class="container">
    <a class="navbar-brand" href="index.htm">
      <img class="logo" src="logo.png" alt="GoElect!" />
    </a>

    <span class="navbar-toggler-icon"></span>
    </button>
  </div>

  <br />

  <br />
  <div class="container">
    <form action="/action_page.php">
      <div class="container">
        <h1>VOTE!</h1>
        <p>Please fill this form to make your choice!</p>
        <hr />
        <form>
          <input type="radio" name="candidate" value="Candidate 1"> Candidate 1<br>
          <input type="radio" name="candidate" value="Candidate 2"> Candidate 2
          <hr />
          <hr />
          <button type="submit" class="registerbtn">Vote</button>
      </div>

  </div>
  </form>
  </div>
</body>

</html> -->

<!DOCTYPE html>
<html>

<head>

  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <style>
    body {
      font-family: Arial, Helvetica, sans-serif;
      background-color: black;
    }

    * {
      box-sizing: border-box;
    }

    /* Add padding to containers */
    .container {
      padding: 16px;
      background-color: white;
    }

    /* Full-width input fields */
    input[type="text"],
    input[type="password"] {
      width: 100%;
      padding: 15px;
      margin: 5px 0 22px 0;
      display: inline-block;
      border: none;
      background: #f1f1f1;
    }

    input[type="text"]:focus,
    input[type="password"]:focus {
      background-color: #ddd;
      outline: none;
    }

    /* Overwrite default styles of hr */
    hr {
      border: 1px solid #f1f1f1;
      margin-bottom: 25px;
    }

    /* Set a style for the submit button */
    .registerbtn {
      background-color: black;
      color: white;
      padding: 16px 20px;
      margin: 8px 0;
      border: none;
      cursor: pointer;
      width: 100%;
      opacity: 0.9;
    }

    .registerbtn:hover {
      opacity: 1;
    }

    /* Add a blue text color to links */
    a {
      color: dodgerblue;
    }

    /* Set a grey background color and center the text of the "sign in" section */
    .signin {
      background-color: #f1f1f1;
      text-align: center;
    }
    .container img{
width: 15%;
 }
  form{
   margin: 20px;
 }
    }


  </style>
</head>

<body>
  <script>
    "use strict"
    let candidate1 = 0;
    let candidate2 = 0;
let totalVotes;
    function addleft(){
      candidate1++;
    totalVotes =candidate1 + candidate2;
    updatePoints();
}
function addright(){
      candidate2++;
    totalVotes ==candidate1 + candidate2;
    updatePoints();
}
function updatePoints(){
  document.getElementById("total-votes").innerHTML = "Total Votes Casted: " + totalVotes;
}
document.getElementById('candidate2-button').addEventListener('click', function () {
  candidate2=candidate2+1;
  updatePoints();
});

document.getElementById('candidate1-button').addEventListener('click', function () {
  candidate1=candidate1+1;
  updatePoints();
});



    </script>
  <div class="container">
    <a class="navbar-brand" href="<?php echo e(url('index')); ?>">
      <img class="logo" src="logo.png" alt="GoElect!" />
    </a>

    <span class="navbar-toggler-icon"></span>
    </button>
  </div>

  <br />

  <br />
  <div class="container">
    <form action="/action_page.php">
      <div class="container">
        <h1>VOTE!</h1>
        <hr />
        <form>
          <img src="c1.jpg"/> 
          <button type="button" id="candidate1-button" onclick="addleft()"> Candidate 1</button>
          <img src="c2.jpg"/> 
          <button type="button" id="candidate2-button" onclick="addright()">Candidate 2 </button>
        <hr />
        <button type="submit" class="registerbtn">Vote</button>
      </div>

      <h3 id="results">
  total: 
  candidate1: 
  candidate2: 
</h3>

  </div>
  </form>
  </div>
</body>
</html><?php /**PATH C:\Users\Soundarya\Desktop\web project\l\resources\views/vote.blade.php ENDPATH**/ ?>